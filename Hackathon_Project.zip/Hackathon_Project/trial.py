import folium
import os
from flask import Flask, request, render_template

app = Flask(__name__)

def main():
    if __name__ == '__main__':
        main()

# Location data
locations = {"UPES": 0, "Nanda Ki Chowki": 1, "Premnagar": 2, "Ballupur": 3, "Clock Tower": 4, "Mussoorie Diversion": 5, "DIT": 6}
cost = {
    "0_to_1.json": 25, "1_to_2.json": 10, "2_to_3.json": 15, "3_to_4.json": 20, "4_to_5.json": 20, "5_to_6.json": 20,
    "1_to_0.json": 25, "2_to_1.json": 10, "3_to_2.json": 20, "4_to_3.json": 20, "5_to_4.json": 20, "6_to_5.json": 20
}
cost_rp = {
    "0_to_1.json": 90, "1_to_2.json": 30, "2_to_3.json": 50, "3_to_4.json": 70, "4_to_5.json": 80, "5_to_6.json": 60,
    "1_to_0.json": 90, "2_to_1.json": 30, "3_to_2.json": 70, "4_to_3.json": 70, "5_to_4.json": 80, "6_to_5.json": 60
}

# Function to create a graph for pathfinding
def nodes(points):
    graph = {}
    for i, j in points:
        if i not in graph:
            graph[i] = []
        graph[i].append(j)
    return graph

# Function to find all paths between two points
def find_all_paths(graph, i, j, path, paths):
    path.append(i)
    if i == j:
        paths.append(path.copy())
    else:
        if i in graph:
            for k in graph[i]:
                if k not in path:
                    find_all_paths(graph, k, j, path, paths)
    path.pop()

# Function to find the shortest path
def find_shortest_path(paths):
    if paths:
        shortest_path = min(paths, key=len)
        return shortest_path
    return None

@app.route('/')
def form():
    return render_template("pyint.html")  # Ensure this HTML file is saved in the 'templates' directory

@app.route('/process', methods=['POST'])
def process_form():
    # Retrieve pickup and drop values from form
    pickup = request.form.get("pickup")
    drop = request.form.get("drop")
    
    # Check for valid inputs
    if not pickup or not drop:
        return "Error: Pickup or Drop location not selected."
    
    # Map location names to numeric indices for pathfinding
    loc = locations.get(pickup)
    des = locations.get(drop)

    # Points defining the connections between locations
    points = [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 6], [6, 5], [5, 4], [4, 3], [3, 2], [2, 1], [1, 0]]
    
    # Generate graph from the points
    graph = nodes(points)
    
    all_paths = []
    find_all_paths(graph, loc, des, [], all_paths)
    
    shortest_path = find_shortest_path(all_paths)

    # Calculate the total costs for both public transport and rapido
    total_cost_pt, total_cost_rp = 0, 0
    if all_paths:
        for path in all_paths:
            for idx in range(len(path) - 1):
                route = f"{path[idx]}_to_{path[idx+1]}.json"
                total_cost_pt += cost.get(route, 0)
                total_cost_rp += cost_rp.get(route, 0)

    # Choose the best transportation option
    suggested_option = "Public Transport" if total_cost_pt < 0.9 * total_cost_rp else "Rapido"
    
    # Generate the map using Folium
    m = folium.Map(location=[30.3165, 78.0322], zoom_start=12)
    
    # Add the path to the map
    if shortest_path:
        for i in range(len(shortest_path)-1):
            final_route = f"{shortest_path[i]}_to_{shortest_path[i+1]}.json"
            # Here you would need to ensure the GeoJSON files exist or are generated for the paths
            walk_data = os.path.join(final_route)
            folium.GeoJson(walk_data, name="walk").add_to(m)

    # Save the map to an HTML file
    map_file_path = "index.html"
    m.save(map_file_path)

    # Render the result template with the information
    return render_template("index.html", pickup=pickup, drop=drop, total_cost_pt=total_cost_pt, total_cost_rp=total_cost_rp, suggested_option=suggested_option, map_file_path=map_file_path)



