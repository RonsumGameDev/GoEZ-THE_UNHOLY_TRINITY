
const locations = {
    "UPES": 0, "Nanda Ki Chowki": 1, "Premnagar": 2,
    "Ballupur": 3, "Clock Tower": 4, "Mussoorie Diversion": 5, "DIT": 6
};

const coords = {
    "UPES": [30.4173, 77.9681], "Nanda Ki Chowki": [30.3435, 77.9531],
    "Premnagar": [30.3361, 77.9646], "Ballupur": [30.3336, 78.0121],
    "Clock Tower": [30.3242, 78.0420], "Mussoorie Diversion": [30.3715, 78.0774],
    "DIT": [30.3980, 78.0753]
};

const cost = {
    "0_to_1": 25, "1_to_2": 10, "2_to_3": 15, "3_to_4": 20,
    "4_to_5": 20, "5_to_6": 20, "1_to_0": 25, "2_to_1": 10,
    "3_to_2": 20, "4_to_3": 20, "5_to_4": 20, "6_to_5": 20
};

const cost_rp = {
    "0_to_1": 90, "1_to_2": 30, "2_to_3": 50, "3_to_4": 70,
    "4_to_5": 80, "5_to_6": 60, "1_to_0": 90, "2_to_1": 30,
    "3_to_2": 70, "4_to_3": 70, "5_to_4": 80, "6_to_5": 60
};

const points = [
    [0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 6],
    [6, 5], [5, 4], [4, 3], [3, 2], [2, 1], [1, 0]
];

function buildGraph(points) {
    let graph = {};
    points.forEach(([i, j]) => {
        if (!graph[i]) graph[i] = [];
        graph[i].push(j);
    });
    return graph;
}

function findAllPaths(graph, start, end, path = [], paths = []) {
    path.push(start);
    if (start === end) {
        paths.push([...path]);
    } else {
        if (graph[start]) {
            graph[start].forEach(neighbor => {
                if (!path.includes(neighbor)) {
                    findAllPaths(graph, neighbor, end, path, paths);
                }
            });
        }
    }
    path.pop();
    return paths;
}

function findShortestPath(paths) {
    return paths.reduce((shortest, path) => path.length < shortest.length ? path : shortest, paths[0]);
}

function calculateCosts(path, costDict) {
    return path.reduce((total, node, i) => {
        if (i < path.length - 1) {
            const key = `${node}_to_${path[i + 1]}`;
            total += costDict[key] || 0;
        }
        return total;
    }, 0);
}

function displayPaths(paths, shortestPath) {
    console.log("All possible paths:");
    paths.forEach((path, index) => {
        console.log(`Path ${index + 1}: ${path.join(" -> ")}`);
    });
    console.log("\nShortest path:", shortestPath.join(" -> "));
}

function initializeMap() {
    const map = L.map('map').setView(coords["UPES"], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 18
    }).addTo(map);

    return map;
}

function plotRoute(map, path) {
    const routeCoordinates = path.map(node => coords[Object.keys(locations).find(key => locations[key] === node)]);
    L.polyline(routeCoordinates, { color: 'blue' }).addTo(map);
}

// Main execution
const loc = prompt("Enter starting location:");
const des = prompt("Enter destination:");

if (loc in locations && des in locations) {
    const graph = buildGraph(points);
    const i = locations[loc];
    const j = locations[des];

    const allPaths = findAllPaths(graph, i, j);
    if (allPaths.length > 0) {
        const shortestPath = findShortestPath(allPaths);
        displayPaths(allPaths, shortestPath);

        const totalCostPT = calculateCosts(shortestPath, cost);
        const totalCostRP = calculateCosts(shortestPath, cost_rp);

        console.log("Total Public Transport Cost:", totalCostPT);
        console.log("Total Rapido Cost:", totalCostRP);
        console.log(totalCostPT < 0.9 * totalCostRP ? "Public Transport is recommended." : "Rapido is recommended for comfort.");

        const map = initializeMap();
        plotRoute(map, shortestPath);
    } else {
        console.log("No paths exist between the selected locations.");
    }
} else {
    console.log("Invalid locations entered.");
}