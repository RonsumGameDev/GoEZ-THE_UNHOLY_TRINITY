from flask import Flask, request, render_template
import folium
import os

app = Flask(__name__)

# Your predefined data structures
cost = {"0_to_1.json": 25, "1_to_2.json": 10, "2_to_3.json": 15, "3_to_4.json": 20, "4_to_5.json": 20, "5_to_6.json": 20, "1_to_0.json": 25, "2_to_1.json": 10, "3_to_2.json": 20, "4_to_3.json": 20, "5_to_4.json": 20, "6_to_5.json": 20}
cost_rp = {"0_to_1.json": 90, "1_to_2.json": 30, "2_to_3.json": 50, "3_to_4.json": 70, "4_to_5.json": 80, "5_to_6.json": 60, "1_to_0.json": 90, "2_to_1.json": 30, "3_to_2.json": 70, "4_to_3.json": 70, "5_to_4.json": 80, "6_to_5.json": 60}
locations = {"UPES": 0, "Nanda Ki Chowki": 1, "Premnagar": 2, "Ballupur": 3, "Clock Tower": 4, "Mussoorie Diversion": 5, "DIT": 6}

@app.route('/')
def form():
    return render_template("pyint.html")

@app.route('/process', methods=['POST'])
def process_form():
    # Retrieve pickup and drop values from form
    loc = request.form.get("pickup")
    des = request.form.get("drop")

    # Perform pathfinding based on `loc` and `des`
    i = locations[loc]
    j = locations[des]

    # Sample pathfinding logic (add your algorithm here)
    total_cost_pt, total_cost_rp = 0, 0
    points = [[0,1], [1,2], [2,3], [3,4], [4,5], [5,6], [6,5], [5,4], [4,3], [3,2], [2,1], [1,0]]
    
    # Define helper functions for pathfinding (like find_all_paths)
    def nodes(points):
        graph = {}
        for a, b in points:
            if a not in graph:
                graph[a] = []
            graph[a].append(b)
        return graph

    def find_all_paths(graph, start, end, path, paths):
        path.append(start)
        if start == end:
            paths.append(path[:])
        elif start in graph:
            for node in graph[start]:
                if node not in path:
                    find_all_paths(graph, node, end, path, paths)
        path.pop()

    graph = nodes(points)
    all_paths = []
    find_all_paths(graph, i, j, [], all_paths)
    
    shortest_path = min(all_paths, key=len) if all_paths else None

    if shortest_path:
        for idx in range(len(shortest_path) - 1):
            route = f"{shortest_path[idx]}_to_{shortest_path[idx+1]}.json"
            total_cost_pt += cost.get(route, 0)
            total_cost_rp += cost_rp.get(route, 0)

    # Save the map
    m = folium.Map(location=[30.3165, 78.0322], zoom_start=12)
    m.save("index.html")

    # Return the result or the map
    result = {
        "pickup": loc,
        "drop": des,
        "public_transport_cost": total_cost_pt,
        "rapido_cost": total_cost_rp,
        "suggestion": "Public Transport" if total_cost_pt < 0.9 * total_cost_rp else "Rapido"
    }
    return render_template("index.html", result=result)

if __name__ == '__main__':
    app.run(debug=True)