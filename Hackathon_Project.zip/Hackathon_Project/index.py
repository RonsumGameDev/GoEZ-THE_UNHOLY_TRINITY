#PATH FINDING ALGORITHM
#i = Starting point
#j = End point
#k = Neighbours

#LIBRARIES
import folium
import folium.features
import folium.map
import os
import pyscript

l = []
total_paths = []
total_cost_pt = 0
total_cost_rp = 0

cost = {"0_to_1.json" : 25, "1_to_2.json" : 10, "2_to_3.json" : 15, "3_to_4.json" : 20, "4_to_5.json" : 20, "5_to_6.json" : 20, "1_to_0.json" : 25, "2_to_1.json" : 10, "3_to_2.json" : 20, "4_to_3.json" : 20, "5_to_4.json" : 20, "6_to_5.json" : 20}
cost_rp = {"0_to_1.json" :90, "1_to_2.json" : 30, "2_to_3.json" : 50, "3_to_4.json" : 70, "4_to_5.json" : 80, "5_to_6.json" : 60, "1_to_0.json" : 90, "2_to_1.json" : 30, "3_to_2.json" : 70, "4_to_3.json" : 70, "5_to_4.json" : 80, "6_to_5.json" : 60}

locations = {"UPES" : 0, "Nanda Ki Chowki" : 1, "Premnagar" : 2, "Ballupur" : 3, "Clock Tower" : 4, "Mussoorie Diversion" : 5, "DIT" : 6}

coords = {"UPES" : [30.4173, 77.9681], "Nanda Ki Chowki" : [30.3435, 77.9531], "Prem Nagar" : [30.3361, 77.9646], "Ballupur" : [30.3336, 78.0121], "Clock Tower" : [30.3242, 78.0420], "Mussoorie Diversion" : [30.3715, 78.0774], "DIT" : [30.3980, 78.0753]}

m = folium.Map(location=[30.4173, 77.9681], zoom_start=15)
iconBus = folium.features.CustomIcon("bus-front-fill.png", icon_size=(25,25))
folium.Marker(location=[30.4173, 77.9681], tooltip="UPES", popup="<strong>UPES</strong>", icon=iconBus).add_to(m)


def nodes(points):
    graph = {}
    for i, j in points:
        if i not in graph:
            graph[i] = []
        graph[i].append(j)
    return graph

def find_all_paths(graph, i, j, path, paths):
    path.append(i)
    if i == j:
        paths.append(path.copy())  
    else:
        if i in graph:
            for k in graph[i]:
                if k not in path:  
                    find_all_paths(graph, k, j, path, paths)
    path.pop()  

def find_shortest_path(paths):
    if paths:
        
        shortest_path = min(paths, key=len)
        return shortest_path
    return None


    # Map location names to numeric indices for pathfinding
loc = str(input())
des = str(input())

points = [[0,1], [1,2], [2,3], [3,4], [4,5], [5,6], [6, 5], [5, 4], [4, 3],[3, 2], [2, 1], [1, 0]]
i = locations[loc]
j = locations[des]
graph = nodes(points)

all_paths = []
find_all_paths(graph, i, j, [], all_paths)

if all_paths:
    print(f"All possible paths from {i} to {j}:")
    for i, path in enumerate(all_paths, 1):
        print(f"Path {i}: {' -> '.join(map(str, path))}")

    shortest_path = find_shortest_path(all_paths)
    print("\nThe shortest path is:")
    print(" -> ".join(map(str, shortest_path)))
else:
    print(f"No paths exist from {i} to {j}")
#path = find_path(graph, i, j, [])

if path:
    print(f"The path from {i} to {j} is : {'->'.join(map(str,path))}")
    

else:
    print(f"There is no path between {i} and {j}")

print(shortest_path)
for i in range(len(all_paths)):
    for j in range(len(all_paths[i]) - 1):
        another_route = (str(str(all_paths[i][j])) + "_to_" + str(all_paths[i][j+1]) + ".json")
        print(another_route)
        walkData = os.path.join(another_route)
        folium.GeoJson(walkData,name="walk").add_to(m)
m.save("./templates/index.html")

for i in range(len(shortest_path)-1):
 
    final_route = (str(shortest_path[i]) + "_to_" + str(shortest_path[i+1]) + ".json")
    total_cost_pt += cost[final_route]
    total_cost_rp += cost_rp[final_route]
    print(final_route)
    walkData = os.path.join(final_route)
    folium.GeoJson(walkData, name="walk").add_to(m)
m.save("./templates/index.html")

print(all_paths)
print("Magic Cost : ", total_cost_pt)
print("Rapido Cost : ", total_cost_rp)

if total_cost_pt < 0.9 * total_cost_rp:
    print("Public Transport would be a better choice!")
else:
    print("Rapido is a better choice, comfort is also a thing :)")
